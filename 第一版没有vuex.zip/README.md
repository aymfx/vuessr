# lr-ssr 

懒人模板 构建在vue2.0 + webpack4 + vue-router + vuex

## Build Setup

**Requires Node.js 7+**

``` bash
# install dependencies
npm install # or yarn

# serve in dev mode, with hot reload at localhost:8080
npm run dev

# build for production
npm run build

# serve in production mode
npm start
```