<template>
    <div>asdasdsdd<router-link to="/">回到首页</router-link></div>
    
</template>